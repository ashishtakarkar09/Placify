import React, { useState, useEffect } from 'react';
import { UserProfile } from './types';
import { DbService } from './services/db';
import Auth from './components/Auth';
import Dashboard from './components/Dashboard';
import CGPAPredictor from './components/CGPAPredictor';
import CompanyChecker from './components/CompanyChecker';
import DSATracker from './components/DSATracker';
import AptitudeTracker from './components/AptitudeTracker';
import ResumeBuilder from './components/ResumeBuilder';
import InterviewPrep from './components/InterviewPrep';
import ContestTracker from './components/ContestTracker';
import NotesManager from './components/NotesManager';
import ProfilePage from './components/ProfilePage';

import {
  LayoutDashboard,
  GraduationCap,
  LineChart,
  StickyNote,
  User,
  LogOut,
  ChevronLeft,
  Briefcase,
  Flame,
  ArrowRight,
  Sparkles
} from 'lucide-react';

export default function App() {
  const [user, setUser] = useState<UserProfile | null>(null);
  const [activeTab, setActiveTab] = useState<string>('dashboard'); // dashboard, progress, notes, profile
  const [activeOverlay, setActiveOverlay] = useState<string | null>(null); // dsa, aptitude, resume, interview, contests
  const [refreshCounter, setRefreshCounter] = useState(0);

  // Load current user from session on mount
  useEffect(() => {
    const session = DbService.getCurrentUser();
    if (session) {
      setUser(session);
    }
  }, []);

  const handleLogout = () => {
    DbService.setCurrentUserSession(null);
    setUser(null);
    setActiveTab('dashboard');
    setActiveOverlay(null);
  };

  const forceRefreshStats = () => {
    setRefreshCounter((prev) => prev + 1);
  };

  // Switch to correct navigation tab and handle special scrolls or actions
  const handleLaunchpadNavigation = (tabName: string) => {
    if (['cgpa'].includes(tabName)) {
      setActiveTab('progress');
      setActiveOverlay(null);
    } else {
      setActiveOverlay(tabName);
    }
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center font-sans">
        <Auth onLoginSuccess={(u) => setUser(u)} />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50/50 flex flex-col font-sans pb-24 select-none">
      {/* Mobile-First Header bar */}
      <header className="bg-white border-b border-slate-100 shadow-xs h-16 flex items-center justify-between px-6 sticky top-0 z-40 select-none">
        <div className="flex items-center gap-2.5">
          <div className="p-1.5 bg-blue-600 text-white rounded-xl shadow-md shadow-blue-500/10">
            <GraduationCap className="w-5 h-5" />
          </div>
          <div>
            <h1 className="text-sm font-black font-display tracking-tight text-slate-800">
              Placify
            </h1>
            <span className="text-[10px] text-slate-400 font-mono block">Placement Readiness Dashboard</span>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => setActiveTab('profile')}
            className="flex items-center gap-2 text-xs font-semibold text-slate-600 hover:text-slate-800 transition cursor-pointer"
          >
            <div className="w-7 h-7 bg-blue-50 text-blue-650 rounded-full flex items-center justify-center font-black border border-blue-100 uppercase">
              {user.fullName.charAt(0)}
            </div>
            <span className="hidden md:inline">{user.fullName.split(' ')[0]}</span>
          </button>
        </div>
      </header>

      {/* Main viewport Container */}
      <main className="max-w-7xl w-full mx-auto p-4 md:p-6 flex-1 relative">
        
        {/* Render overlay view with full screen slide-in simulation */}
        {activeOverlay ? (
          <div className="animate-fade-in space-y-4">
            <button
              onClick={() => {
                setActiveOverlay(null);
                forceRefreshStats();
              }}
              className="flex items-center gap-2 px-3 py-1.5 bg-white border border-slate-100 rounded-xl text-xs font-bold text-slate-600 hover:text-slate-800 hover:shadow-xs transition cursor-pointer"
            >
              <ChevronLeft className="w-4 h-4 text-blue-600" />
              <span>Back to Student Dashboard</span>
            </button>

            {activeOverlay === 'dsa' && <DSATracker user={user} onChange={forceRefreshStats} />}
            {activeOverlay === 'aptitude' && <AptitudeTracker user={user} onChange={forceRefreshStats} />}
            {activeOverlay === 'resume' && <ResumeBuilder user={user} onChange={forceRefreshStats} />}
            {activeOverlay === 'interview' && <InterviewPrep user={user} onChange={forceRefreshStats} />}
            {activeOverlay === 'contests' && <ContestTracker />}
          </div>
        ) : (
          /* Render main tab navigation views */
          <div className="animate-fade-in-slow">
            {activeTab === 'dashboard' && (
              <Dashboard
                user={user}
                onNavigateToTab={handleLaunchpadNavigation}
                triggerRefresh={refreshCounter}
              />
            )}
            
            {activeTab === 'progress' && (
              <div className="space-y-6">
                <CGPAPredictor user={user} />
                <CompanyChecker user={user} />
              </div>
            )}
            
            {activeTab === 'notes' && <NotesManager user={user} />}
            
            {activeTab === 'profile' && (
              <ProfilePage
                user={user}
                onLogout={handleLogout}
                onUpdateUser={(updated) => {
                  setUser(updated);
                  forceRefreshStats();
                }}
              />
            )}
          </div>
        )}
      </main>

      {/* Bottom Sticky Mobile Navigation Bar */}
      <nav className="bg-white border-t border-slate-100 shadow-xl fixed bottom-0 left-0 right-0 h-16 flex justify-around items-center px-4 z-40 select-none">
        
        {/* Button 1: Dashboard */}
        <button
          onClick={() => {
            setActiveTab('dashboard');
            setActiveOverlay(null);
          }}
          className={`flex flex-col items-center justify-center gap-0.5 w-16 h-12 rounded-xl transition cursor-pointer ${
            activeTab === 'dashboard' && !activeOverlay
              ? 'text-blue-600 font-bold'
              : 'text-slate-400 hover:text-slate-700'
          }`}
        >
          <LayoutDashboard className="w-5 h-5" />
          <span className="text-[10px]">Dashboard</span>
        </button>

        {/* Button 2: Progress (CGPA + Company check) */}
        <button
          onClick={() => {
            setActiveTab('progress');
            setActiveOverlay(null);
          }}
          className={`flex flex-col items-center justify-center gap-0.5 w-16 h-12 rounded-xl transition cursor-pointer ${
            activeTab === 'progress' && !activeOverlay
              ? 'text-blue-600 font-bold'
              : 'text-slate-400 hover:text-slate-700'
          }`}
        >
          <LineChart className="w-5 h-5" />
          <span className="text-[10px]">Progress</span>
        </button>

        {/* Button 3: Notes */}
        <button
          onClick={() => {
            setActiveTab('notes');
            setActiveOverlay(null);
          }}
          className={`flex flex-col items-center justify-center gap-0.5 w-16 h-12 rounded-xl transition cursor-pointer ${
            activeTab === 'notes' && !activeOverlay
              ? 'text-blue-600 font-bold'
              : 'text-slate-400 hover:text-slate-700'
          }`}
        >
          <StickyNote className="w-5 h-5" />
          <span className="text-[10px]">Notes</span>
        </button>

        {/* Button 4: Profile */}
        <button
          onClick={() => {
            setActiveTab('profile');
            setActiveOverlay(null);
          }}
          className={`flex flex-col items-center justify-center gap-0.5 w-16 h-12 rounded-xl transition cursor-pointer ${
            activeTab === 'profile' && !activeOverlay
              ? 'text-blue-600 font-bold'
              : 'text-slate-400 hover:text-slate-700'
          }`}
        >
          <User className="w-5 h-5" />
          <span className="text-[10px]">Profile</span>
        </button>
      </nav>
    </div>
  );
}

