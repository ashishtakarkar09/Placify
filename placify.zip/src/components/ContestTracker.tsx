import React, { useState, useEffect } from 'react';
import { Contest, INITIAL_CONTESTS } from '../types';
import { Calendar, Clock, AlertTriangle, ExternalLink, RefreshCw, BellRing } from 'lucide-react';

export default function ContestTracker() {
  const [contests, setContests] = useState<Contest[]>(() => INITIAL_CONTESTS());

  // Set up seconds ticks to run dynamic countdown on mount
  useEffect(() => {
    const timer = setInterval(() => {
      setContests((prevContests) =>
        prevContests.map((c) => {
          const now = new Date();
          const target = new Date(c.startTime);
          const diffMs = target.getTime() - now.getTime();
          const secondsLeft = Math.max(0, Math.round(diffMs / 1000));
          return {
            ...c,
            secondsLeft
          };
        })
      );
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  // Format dynamic ticking clock
  const formatCountdown = (totalSeconds: number) => {
    if (totalSeconds <= 0) return 'Live Now!';

    const days = Math.floor(totalSeconds / (24 * 3600));
    const hours = Math.floor((totalSeconds % (24 * 3600)) / 3600);
    const minutes = Math.floor((totalSeconds % 3600) / 60);
    const seconds = totalSeconds % 60;

    const parts = [];
    if (days > 0) parts.push(`${days}d`);
    parts.push(`${hours.toString().padStart(2, '0')}h`);
    parts.push(`${minutes.toString().padStart(2, '0')}m`);
    parts.push(`${seconds.toString().padStart(2, '0')}s`);

    return parts.join(' ');
  };

  // Check state-based timer notification thresholds:
  // - Starts in < 24 Hours
  // - Starts in < 1 Hour
  // - Starts in < 10 Minutes
  const getTimerNotification = (totalSeconds: number) => {
    if (totalSeconds <= 0) {
      return { text: 'Contest is LIVE! Join the register board immediately.', color: 'text-rose-700 bg-rose-50 border-rose-200' };
    }
    if (totalSeconds <= 10 * 60) {
      return { text: 'CRITICAL: Contest starts in weniger als 10 minutes! Prepare your workspace now.', color: 'text-amber-700 bg-amber-50 border-amber-200 animate-pulse' };
    }
    if (totalSeconds <= 60 * 60) {
      return { text: 'ALERT: Contest starts in less than 1 hour! Review code templates.', color: 'text-blue-700 bg-blue-50 border-blue-200' };
    }
    if (totalSeconds <= 24 * 60 * 60) {
      return { text: 'Upcoming task: Contest starts within 24 hours.', color: 'text-slate-600 bg-slate-50 border-slate-200' };
    }
    return null;
  };

  // Reset contests schedule (simulated sync)
  const handleManualSync = () => {
    setContests(INITIAL_CONTESTS());
  };

  return (
    <div className="space-y-6">
      {/* Contest header info */}
      <div className="bg-white border border-slate-100 rounded-3xl p-6 shadow-sm">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-blue-100 text-blue-600 rounded-2xl">
              <Calendar className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-slate-800">Competitive Coding Contest Tracker</h2>
              <p className="text-xs text-slate-400">Never miss a platform rating contest on LeetCode, Codeforces, or CodeChef</p>
            </div>
          </div>

          <button
            onClick={handleManualSync}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-50 hover:bg-slate-100 text-slate-600 rounded-xl text-xs font-semibold cursor-pointer border border-slate-100 transition whitespace-nowrap self-start md:self-auto"
          >
            <RefreshCw className="w-3.5 h-3.5" /> Force Sync Calendar
          </button>
        </div>
      </div>

      {/* Notifications and counts alert */}
      <div className="space-y-3">
        <h3 className="text-xs font-bold font-mono tracking-wider text-slate-500 uppercase flex items-center gap-1.5">
          <BellRing className="w-4 h-4 text-violet-600" /> Active System Reminders
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {contests.map((c) => {
            const reminder = getTimerNotification(c.secondsLeft);
            if (!reminder) return null;

            return (
              <div key={`rem_${c.id}`} className={`p-4 rounded-xl border flex gap-3 text-xs leading-normal font-semibold ${reminder.color}`}>
                <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
                <div>
                  <strong className="block text-slate-850 text-[11px] font-bold font-mono">{c.platform} Reminder:</strong>
                  <span className="mt-1 block text-slate-600 font-medium">{reminder.text}</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Main Contests list details */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-2">
        {contests.map((c) => {
          const isLive = c.secondsLeft <= 0;

          return (
            <div
              key={c.id}
              className={`bg-white border rounded-3xl p-6 shadow-xs flex flex-col justify-between space-y-5 transition-all duration-200 hover:border-slate-300 relative overflow-hidden ${
                isLive ? 'border-rose-300' : 'border-slate-100'
              }`}
            >
              {isLive && (
                <div className="absolute top-0 right-0 bg-rose-600 text-white text-[9px] font-black tracking-widest px-3 py-1 rounded-bl-xl uppercase select-none">
                  Live Contest
                </div>
              )}

              <div className="space-y-3">
                <div>
                  <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-mono font-black border uppercase ${
                    c.platform === 'LeetCode'
                      ? 'bg-amber-50 text-amber-700 border-amber-100'
                      : c.platform === 'Codeforces'
                      ? 'bg-blue-50 text-blue-700 border-blue-100'
                      : 'bg-emerald-50 text-emerald-700 border-emerald-100'
                  }`}>
                    {c.platform}
                  </span>
                  <h4 className="text-base font-extrabold text-slate-800 tracking-tight mt-2.5 leading-snug truncate">
                    {c.title}
                  </h4>
                </div>

                <div className="space-y-2 text-xs text-slate-500">
                  <div className="flex items-center gap-1.5 font-mono">
                    <Clock className="w-4 h-4 text-slate-400 shrink-0" />
                    <span>Duration: <strong className="text-slate-700">{c.duration}</strong></span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <Calendar className="w-4 h-4 text-slate-400 shrink-0" />
                    <span className="text-[11px] truncate">
                      Starts: {new Date(c.startTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: true })}
                    </span>
                  </div>
                </div>
              </div>

              {/* Countdown Ticker Box */}
              <div className="pt-3 border-t border-slate-100 flex items-center justify-between gap-2 select-none">
                <div className="min-w-0">
                  <span className="text-[10px] uppercase font-bold text-slate-400 font-mono block">Countdown:</span>
                  <span className={`font-mono text-sm font-black tracking-tight truncate block ${
                    isLive ? 'text-rose-600' : 'text-slate-800'
                  }`}>
                    {formatCountdown(c.secondsLeft)}
                  </span>
                </div>

                <a
                  href={c.link}
                  target="_blank"
                  referrerPolicy="no-referrer"
                  className="flex items-center gap-1 px-3 py-2 bg-slate-50 hover:bg-blue-600 hover:text-white text-blue-600 text-xs font-bold rounded-xl transition cursor-pointer border border-slate-100 shrink-0"
                >
                  <span>Link</span>
                  <ExternalLink className="w-3 h-3" />
                </a>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
